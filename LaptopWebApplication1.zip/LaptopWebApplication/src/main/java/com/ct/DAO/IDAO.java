package com.ct.DAO;

import org.springframework.stereotype.Component;

import com.ct.Model.*;

@Component
public interface IDAO {
	public String accountValidation(Login logObj); 
	public String createAccount(Account accObj);
	
}
