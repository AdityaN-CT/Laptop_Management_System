package com.ct.Model;

import javax.validation.constraints.Size;

public class Login {
	private String userName;
	
	@Size(min = 8, message = "The password length must be greater than 8")
	private String password;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public Login() {
		
	}

}
