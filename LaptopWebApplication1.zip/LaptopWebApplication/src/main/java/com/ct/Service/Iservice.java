package com.ct.Service;

import org.springframework.stereotype.Component;

import com.ct.Model.Account;
import com.ct.Model.Login;

@Component
public interface Iservice {

	public String accountValidation(Login logObj);
	public String createAccount(Account accObj);

}
