package com.ct.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ct.DAO.DAOImpl;
import com.ct.DAO.IDAO;
import com.ct.Model.Account;
import com.ct.Model.Login;

@Component("serviceObj")
public class ServiceLayer implements Iservice {
	
	@Autowired
	DAOImpl databaseObj;
	
	public String accountValidation(Login logObj) {

		return databaseObj.accountValidation(logObj);
	}

	public String createAccount(Account accObj) {
		System.out.println("service");
		return databaseObj.createAccount(accObj);
	}

}
