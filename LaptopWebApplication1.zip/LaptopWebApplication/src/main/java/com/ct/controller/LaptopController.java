package com.ct.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ct.Model.Account;
import com.ct.Model.Login;
import com.ct.Service.Iservice;
import com.ct.Service.ServiceLayer;

@Controller
public class LaptopController {
	
	@Autowired
	ServiceLayer serviceObj;
	public LaptopController() {
	
	}
	
	@RequestMapping("/")
	public ModelAndView indexPage() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("login_details", new Login());
		mv.addObject("accDetails", new Account());
		mv.setViewName("index");
		return mv;
	}
	
	
 /*@RequestMapping("/signUp")
	public ModelAndView createAccount()
	{
	 ModelAndView mv = new ModelAndView();
	 mv.addObject("accDetails", new Account());
	 System.out.println("here");
	 mv.setViewName("signUp");
		return mv;
	 
	}*/
	
	@RequestMapping(value = "/signUp", method = RequestMethod.POST )
		public String createAccount(@ModelAttribute("accDetails") Account accObj) {
		System.out.println("acc");
		
			return serviceObj.createAccount(accObj);
		
	}
/*	@RequestMapping("/login")
	public ModelAndView login() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("login_details", new Login());
		mv.setViewName("index");
		return mv;
	}*/
	
	@RequestMapping(value = "/loginDetails", method = RequestMethod.POST)
	public String loginVerification(@ModelAttribute("login_details") Login logObj) {
		return serviceObj.accountValidation(logObj);
		
		
	}
	
	
}
