package com.LaptopManagementSystem.Database;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import com.LaptopManagementSystem.Exception.PersonException;
import com.LaptopManagementSystem.model.Laptop;
import com.LaptopManagementSystem.util.DbUtil;
import com.LaptopManagementSystem.util.IQueryMapper;



public class LaptopDAOImpl implements ILaptopDAO {
	FileInputStream fis;
	OutputStream fout;
	Connection connection = null;
	Laptop lp = null;
	@Override
	public void Account_Validation(String un, String pwd, int option) throws IOException,  PersonException {
		
		Properties prop = new Properties();
		if (option == 1) {
			fis = new FileInputStream("E:\\JAVA\\LaptopManagementSystem\\src\\Admin_Login.properties");
			prop.load(fis);
			if(prop.containsKey(un)) {
				if (!pwd.equals(prop.get(un))) 
					//System.out.println(prop.getProperty(un));
					//System.out.println(pwd);
					throw new PersonException("Invalid Password");
				
			}
			else {
				throw new PersonException("Invalid Username");
		
			}
		
		}
		else {
			fis = new FileInputStream("E:\\JAVA\\LaptopManagementSystem\\src\\Customer_Login.properties");
			prop.load(fis);
			if(prop.containsKey(un)) {
				if (!pwd.equals(prop.get(un))) 
					//System.out.println(prop.getProperty(un));
					//System.out.println(pwd);
					throw new PersonException("Invalid Password");
				
			}
			else {
				throw new PersonException("Invalid Username");
		
			}
		
		
		}
		
		
	}

	@Override
	/*public void Add_Laptop(Laptop lp_obj) throws IOException {
		fout = new FileOutputStream("E:\\JAVA\\LaptopManagementSystem\\src\\LaptopDetails.properties", true);
		Properties prop = new Properties();
		prop.setProperty(String.valueOf(lp_obj.getLaptop_ID()), lp_obj.getName() + " " + lp_obj.getRAM() + " " + lp_obj.getStorage() + " " +lp_obj.getPrice());
		prop.store(fout, null);
		
	}*/
	
	public void Add_Laptop (Laptop lp_obj) throws PersonException {
		connection = DbUtil.getDBConnection();
		try {
			
			PreparedStatement st = connection.prepareStatement(IQueryMapper.INSERT);
			st.setInt(1, lp.getLaptop_ID());
			st.setString(2, lp.getName());
			st.setInt(3, lp.getRAM());
			st.setInt(4, lp.getStorage());
			st.setFloat(5, lp.getPrice());
			st.execute();
		
		
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new PersonException("LaptopDB not found :: " + e.getMessage());
		}
	}
	
////////////////////////////////////////////////////////////////////////////////
	/*@Override
	public Object Search_Mobile(String ID) throws PersonException, IOException {
		fis = new FileInputStream("E:\\JAVA\\LaptopManagementSystem\\src\\LaptopDetails.properties");
		Properties prop = new Properties();
		prop.load(fis);
		if (!prop.containsKey(ID)) {
			throw new PersonException("Does Not Exist");
		}
		else {
			return prop.get(ID);
		}
	
	}
*/
	/////////////////////////////////////////////////////////////////////////////
	public Laptop search_by_id(int id) throws PersonException {
		 connection = DbUtil.getDBConnection();
		try {
			PreparedStatement st = connection.prepareStatement(IQueryMapper.RETRIEVAL_BY_ID);
			st.setInt(1, id);
			ResultSet rs = st.executeQuery();
			if(rs.next()) {
				lp = new Laptop();
				lp.setLaptop_ID(rs.getInt(1));
				lp.setName(rs.getString(2));
				lp.setRAM(rs.getInt(3));
				lp.setStorage(rs.getInt(4));
				lp.setPrice(rs.getFloat(5));
			}
			else {
				throw new PersonException("Laptop Not Found");
			}
		
		
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new PersonException("Data not found :: " + e.getMessage());
		}
		
		
		return lp;
		}
////////////////////////////////////////////////////////////////////////////	
	@Override
	public Object display_all() {
		return fis;

		
	}

}
