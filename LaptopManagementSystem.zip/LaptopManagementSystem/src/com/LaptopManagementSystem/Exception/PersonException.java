package com.LaptopManagementSystem.Exception;

public class PersonException extends Exception{
	
	public PersonException() {
		
	}
	
	public PersonException(String s) {
		super(s);
	}

}
