/************************************************************************************************************

Author: Aditya Nair

The following is databse code for Laptop Management System.









***************************************************************************************************************/
package com.LaptopManagementSystem.Database;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.LaptopManagementSystem.Exception.PersonException;
import com.LaptopManagementSystem.model.Laptop;
import com.LaptopManagementSystem.util.DbUtil;
import com.LaptopManagementSystem.util.IQueryMapper;

public class LaptopDAOImpl implements ILaptopDAO {
	FileInputStream fis;
	OutputStream fout;
	Connection connection = null;
	Laptop Laptop_Object = null;
	String problem = "We are having problem in accessing database.\n Sorry for your inconvience.\n Please try again later\n";

	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void account_Validation(String username, String password, int option) throws IOException, PersonException {

		Properties prop = new Properties();
		if (option == 1) {
			fis = new FileInputStream(
					"C:\\Users\\Trainingvdi\\Desktop\\JAVA\\LMS\\LaptopManagementSystem\\src\\Admin_Login.properties");
			prop.load(fis);
			if (prop.containsKey(username)) {
				if (!password.equals(prop.get(username)))
					throw new PersonException("Invalid Password");
			}
			 else {
				throw new PersonException("Invalid Username");

			}

		} 
		else {
			fis = new FileInputStream(
					"C:\\Users\\Trainingvdi\\Desktop\\JAVA\\LMS\\LaptopManagementSystem\\src\\Customer_Login.properties");
			prop.load(fis);
			if (prop.containsKey(username)) {
				if (!password.equals(prop.get(username)))
					throw new PersonException("Invalid Password");

			} else {
				throw new PersonException("Invalid Username");
			}
		}
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public void add_Laptop(Laptop Laptop_Object) throws PersonException {
		connection = DbUtil.getDBConnection();
		try {

			PreparedStatement prep_statement = connection.prepareStatement(IQueryMapper.INSERT);
			// st.setInt(1, Laptop_Object.getLaptop_ID());
			prep_statement.setString(1, Laptop_Object.getName());
			prep_statement.setInt(2, Laptop_Object.getRAM());
			prep_statement.setInt(3, Laptop_Object.getStorage());
			prep_statement.setFloat(4, Laptop_Object.getPrice());
			prep_statement.execute();
		} 
		catch (SQLException e) {
			throw new PersonException(problem+ e.getMessage());
		}
	}

	////////////////////////////////////////////////////////////////////////////////

	public Laptop search_by_id(int id) throws PersonException {
		connection = DbUtil.getDBConnection();
		try {
			PreparedStatement prep_statement = connection.prepareStatement(IQueryMapper.RETRIEVAL_BY_ID);
			prep_statement.setInt(1, id);
			ResultSet result_set = prep_statement.executeQuery();
			if (result_set.next()) {
				Laptop_Object = new Laptop();
				Laptop_Object.setLaptop_ID(result_set.getInt(1));
				Laptop_Object.setName(result_set.getString(2));
				Laptop_Object.setRAM(result_set.getInt(3));
				Laptop_Object.setStorage(result_set.getInt(4));
				Laptop_Object.setPrice(result_set.getFloat(5));
			} else {
				throw new PersonException("Data does not exist");
			}
		} 
		catch (SQLException e) {
			throw new PersonException(problem + e.getMessage());
		}
		return Laptop_Object;
	}

	////////////////////////////////////////////////////////////////////////////

	@Override
	public Collection display_all() throws PersonException {
		Map<Integer, Laptop> Laptop_Details = new HashMap<>();
		connection = DbUtil.getDBConnection();
		try {
			PreparedStatement prep_statement = connection.prepareStatement(IQueryMapper.RETRIEVE_ALL);
			ResultSet result_set = prep_statement.executeQuery();
			if (result_set.next()) {
				do {
					Laptop_Object = new Laptop();
					Laptop_Object.setLaptop_ID(result_set.getInt(1));
					Laptop_Object.setName(result_set.getString(2));
					Laptop_Object.setRAM(result_set.getInt(3));
					Laptop_Object.setStorage(result_set.getInt(4));
					Laptop_Object.setPrice(result_set.getFloat(5));
					Laptop_Details.put(result_set.getInt(1), Laptop_Object);
				} while (result_set.next());
			} 
			else {
				throw new PersonException("problem");
			}
		} 
		catch (SQLException e) {
			throw new PersonException(problem);
		}

		return Laptop_Details.values();

	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public void create_Account(String username, String password) throws PersonException {
		Properties prop = new Properties();
		try {
			fout = new FileOutputStream(
					"C:\\Users\\Trainingvdi\\Desktop\\JAVA\\LMS\\LaptopManagementSystem\\src\\Customer_Login.properties", true);
			prop.setProperty(username, password);
			prop.store(fout, null);
		} 
		catch (FileNotFoundException e) {
			throw new PersonException(problem);
			} 
		catch (IOException e) {
			throw new PersonException(problem);

		}
	}
}
