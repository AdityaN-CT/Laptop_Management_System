/************************************************************************************************************

Author: Aditya Nair











***************************************************************************************************************/
package com.LaptopManagementSystem.ServiceLayer;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;

import com.LaptopManagementSystem.Database.*;
import com.LaptopManagementSystem.Exception.PersonException;
import com.LaptopManagementSystem.model.Laptop;

public class ServiceLayerImpl implements IServiceLayer {
	ILaptopDAO ref = new LaptopDAOImpl();

	@Override
	public void account_Validation(String username, String password, int option)
			throws FileNotFoundException, IOException, PersonException {
		ref.account_Validation(username, password, option);

	}

	public void add_Laptop(Laptop lp_obj) throws IOException, PersonException {
		ref.add_Laptop(lp_obj);

	}

	public Laptop search_by_id(int ID) throws PersonException {
		return ref.search_by_id(ID);

	}

	public Collection display_all() throws PersonException {
		return ref.display_all();
	}

	public void create_Account(String username, String password) throws PersonException, IOException {
		ref.create_Account(username, password);
	}

}
