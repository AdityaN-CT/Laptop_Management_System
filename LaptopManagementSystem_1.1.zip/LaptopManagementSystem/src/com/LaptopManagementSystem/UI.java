/************************************************************************************************************

Author: Aditya Nair











***************************************************************************************************************/
package com.LaptopManagementSystem;

import java.io.FileNotFoundException;

import java.io.IOException;
import java.util.*;

import com.LaptopManagementSystem.Exception.PersonException;
import com.LaptopManagementSystem.ServiceLayer.*;
import com.LaptopManagementSystem.model.*;
import com.LaptopManagementSystem.Exception.*;
public class UI {

	public static void main(String[] args) throws FileNotFoundException, IOException, PersonException {
		IServiceLayer ref = new ServiceLayerImpl();
		Scanner input = new Scanner(System.in);
		Laptop Laptop_obj = new Laptop();
		while(true)
			out:
			{
			System.out.println("Welcome To World Of Laptops\n"
					+"Who are You?\n"
					+ "1. Admin\n"
					+ "2. Customer\n"
					+ "3.Exit");
		
			switch(input.nextInt()) {
		

				case 1:
					{	
						System.out.println("Username : ");
						String username = input.next();
						System.out.println("Password : ");
						String password = input.next();
						try {
							int option = 1;
							ref.account_Validation(username, password, option);
							System.out.println("Login Successful");
						}
						catch (PersonException p){
							System.out.println(p.getMessage());
							break out;
		
						}
						while(true) {
							System.out.println("Welcome to World Of Laptops \n"
									+ "1. Add Laptop \n"
									+ "2. Search By ID \n"
									+ "3. Display All Laptop\n"
									+ "4. Logout\n");
							switch(input.nextInt()) {
								case 1:
									System.out.println("Enter Details Of Laptop");
									//Laptop_obj.setLaptop_ID(input.nextInt());
									System.out.println("Enter Brand Name of Laptop");
									Laptop_obj.setName(input.next());
									System.out.println("Enter RAM of Laptop");
									Laptop_obj.setRAM(input.nextInt());
									System.out.println("Enter Storage of Laptop");
									Laptop_obj.setStorage(input.nextInt());
									System.out.println("Enter Price Of Laptop");
									Laptop_obj.setPrice(input.nextFloat());
									ref.add_Laptop(Laptop_obj);
									System.out.println("DATA ADDED SUCCESSFULLY\n");
									break;
								case 2:
									System.out.println("Enter ID");
									try {
										System.out.println(ref.search_by_id(input.nextInt()));
		
									}
									catch(PersonException p){
										System.out.println(p.getMessage());
									}
									break;
								case 3:
									System.out.println(ref.display_all());
									break;
		
								case 4: break out;
								default:
									System.out.println("Please Enter Valid Option");
									break;
							}	
						}
					}
		
				case 2:
				{
					System.out.println("1.Sign In\n"
							+ "2.Sign Up");
					switch(input.nextInt()) {
			
						case 1:
							System.out.println("Username : ");
							String username = input.next();
							System.out.println("Password : ");
							String password = input.next();
							try {
								int option = 2;
								ref.account_Validation(username, password, option);
								System.out.println("Login Successful");
							}
							catch (PersonException p){
								System.out.println(p.getMessage()); 
								break out;
							}
							while(true) {
								System.out.println("Welcome to World Of Laptops \n"
										+ "1. Display All Laptops\n"
										+ "2.Logout");
								switch(input.nextInt()) {
								case 1:	System.out.println(ref.display_all());
									break;
								case 2: break out;
								default:
									System.out.println("Please Enter Valid Option");
									break;
								}
							}
						case 2:
							System.out.println("Enter Username");
							username = input.next();
							System.out.println("Enter Password");
							password = input.next();
							ref.create_Account(username, password);
							break out;
					}
				}
		
				case 3:
					System.exit(0);
				default:
					System.out.println("Please Enter Valid Option");
					break;
			}
			}
		}	
	}
	
