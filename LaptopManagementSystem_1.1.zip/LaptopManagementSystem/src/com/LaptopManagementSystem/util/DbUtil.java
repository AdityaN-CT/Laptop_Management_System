/************************************************************************************************************

Author: Aditya Nair











***************************************************************************************************************/
package com.LaptopManagementSystem.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.LaptopManagementSystem.Exception.PersonException;

public class DbUtil {
	public static Connection con = null;
	private static FileInputStream fis = null;
	
	public static Connection getDBConnection() throws PersonException {
		
			try {
				fis = new FileInputStream("C:\\Users\\AdityaN\\Desktop\\Java\\LaptopManagementSystem\\src\\LaptopDBconfig.properties");
				Properties prop = new Properties();
				prop.load(fis);
				con = DriverManager.getConnection(prop.getProperty("db.url"), prop.getProperty("db.un"), prop.getProperty("db,pwd"));
		
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				throw new PersonException(e.getMessage());
			}
			
			catch (IOException e) {
				// TODO Auto-generated catch block
				throw new PersonException(e.getMessage());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new PersonException(e.getMessage());
			}
		return con;
	}
}
