/************************************************************************************************************

Author: Aditya Nair











***************************************************************************************************************/
package com.LaptopManagementSystem.Database;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.LaptopManagementSystem.Exception.PersonException;
import com.LaptopManagementSystem.model.Laptop;
import com.LaptopManagementSystem.util.DbUtil;
import com.LaptopManagementSystem.util.IQueryMapper;

public class LaptopDAOImpl implements ILaptopDAO {
	FileInputStream fis;
	OutputStream fout;
	Connection connection = null;
	Laptop Laptop_Object = null;

	///////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void account_Validation(String un, String pwd, int option) throws IOException, PersonException {

		Properties prop = new Properties();
		if (option == 1) {
			fis = new FileInputStream(
					"C:\\Users\\AdityaN\\Desktop\\Java\\LaptopManagementSystem\\src\\Admin_Login.properties");
			prop.load(fis);
			if (prop.containsKey(un)) {
				if (!pwd.equals(prop.get(un)))
					throw new PersonException("Invalid Password");
			}
			 else {
				throw new PersonException("Invalid Username");

			}

		} 
		else {
			fis = new FileInputStream(
					"C:\\Users\\AdityaN\\Desktop\\Java\\LaptopManagementSystem\\src\\Customer_Login.properties");
			prop.load(fis);
			if (prop.containsKey(un)) {
				if (!pwd.equals(prop.get(un)))
					throw new PersonException("Invalid Password");

			} else {
				throw new PersonException("Invalid Username");
			}
		}
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public void add_Laptop(Laptop Laptop_Object) throws PersonException {
		connection = DbUtil.getDBConnection();
		try {

			PreparedStatement st = connection.prepareStatement(IQueryMapper.INSERT);
			// st.setInt(1, Laptop_Object.getLaptop_ID());
			st.setString(1, Laptop_Object.getName());
			st.setInt(2, Laptop_Object.getRAM());
			st.setInt(3, Laptop_Object.getStorage());
			st.setFloat(4, Laptop_Object.getPrice());
			st.execute();
		} 
		catch (SQLException e) {
			throw new PersonException(
					"We are having problem in accessing database.\n Sorry for your inconvience.\n Please try again later "
							+ e.getMessage());
		}
	}

	////////////////////////////////////////////////////////////////////////////////

	public Laptop search_by_id(int id) throws PersonException {
		connection = DbUtil.getDBConnection();
		try {
			PreparedStatement st = connection.prepareStatement(IQueryMapper.RETRIEVAL_BY_ID);
			st.setInt(1, id);
			ResultSet rs = st.executeQuery();
			if (rs.next()) {
				Laptop_Object = new Laptop();
				Laptop_Object.setLaptop_ID(rs.getInt(1));
				Laptop_Object.setName(rs.getString(2));
				Laptop_Object.setRAM(rs.getInt(3));
				Laptop_Object.setStorage(rs.getInt(4));
				Laptop_Object.setPrice(rs.getFloat(5));
			} else {
				throw new PersonException("Laptop Not Found");
			}
		} 
		catch (SQLException e) {
			throw new PersonException("Data not found :: " + e.getMessage());
		}
		return Laptop_Object;
	}

	////////////////////////////////////////////////////////////////////////////

	@Override
	public Collection display_all() throws PersonException {
		Map<Integer, Laptop> Laptop_Details = new HashMap<>();
		connection = DbUtil.getDBConnection();
		try {
			PreparedStatement st = connection.prepareStatement(IQueryMapper.RETRIEVE_ALL);
			ResultSet rs = st.executeQuery();
			if (rs.next()) {
				do {
					Laptop_Object = new Laptop();
					Laptop_Object.setLaptop_ID(rs.getInt(1));
					Laptop_Object.setName(rs.getString(2));
					Laptop_Object.setRAM(rs.getInt(3));
					Laptop_Object.setStorage(rs.getInt(4));
					Laptop_Object.setPrice(rs.getFloat(5));
					Laptop_Details.put(rs.getInt(1), Laptop_Object);
				} while (rs.next());
			} 
			else {
				throw new PersonException("Laptop Not Found");
			}
		} 
		catch (SQLException e) {
			throw new PersonException("Table not found :: " + e.getMessage());
		}

		return Laptop_Details.values();

	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public void create_Account(String un, String pwd) throws PersonException {
		Properties prop = new Properties();
		try {
			fout = new FileOutputStream(
					"C:\\Users\\AdityaN\\Desktop\\Java\\LaptopManagementSystem\\src\\Customer_Login.properties", true);
			prop.setProperty(un, pwd);
			prop.store(fout, null);
		} 
		catch (FileNotFoundException e) {
			throw new PersonException(
					"We are having problem in accessing database.\n Sorry for your inconvience.\n Please try again later");
		} 
		catch (IOException e) {
			throw new PersonException(
					"We are having problem in accessing database.\n Sorry for your inconvience.\n Please try again later");

		}
	}
}
