package com.LaptopManagementSystem.Database;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;

import com.LaptopManagementSystem.Exception.PersonException;
import com.LaptopManagementSystem.model.Laptop;

public interface ILaptopDAO {
	public void account_Validation(String un, String pwd, int option) throws FileNotFoundException, IOException, PersonException;

	public void add_Laptop(Laptop lp_obj) throws FileNotFoundException, IOException, PersonException;

	public Laptop search_by_id(int id) throws PersonException;

	public Collection display_all() throws PersonException;

	public void create_Account(String un, String pwd) throws PersonException, IOException;
	
}
