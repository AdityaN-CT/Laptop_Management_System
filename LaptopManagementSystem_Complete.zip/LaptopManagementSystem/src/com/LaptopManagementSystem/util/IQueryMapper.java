package com.LaptopManagementSystem.util;



public interface IQueryMapper {
	public static final String RETRIEVAL_BY_ID="SELECT * FROM LaptopDetails WHERE Laptop_ID=?";
	public static final String INSERT="INSERT INTO laptopdetails (Laptop_Name, RAM, Storage, Price) VALUES ( ?, ?, ?, ?)";
	public static final String RETRIEVE_ALL = "SELECT * FROM laptopdetails";
}

	
