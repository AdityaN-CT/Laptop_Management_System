package com.LaptopManagementSystem;

import java.io.FileNotFoundException;

import java.io.IOException;
import java.util.*;

import com.LaptopManagementSystem.Exception.PersonException;
import com.LaptopManagementSystem.ServiceLayer.*;
import com.LaptopManagementSystem.model.*;
import com.LaptopManagementSystem.Exception.*;
public class UI {

	public static void main(String[] args) throws FileNotFoundException, IOException, PersonException {
		IServiceLayer ref = new ServiceLayerImpl();
		Scanner scn = new Scanner(System.in);
		Laptop Lp_obj = new Laptop();
		while(true)
		out:
		{
		System.out.println("Who are You?\n"
				+ "1. Admin\n"
				+ "2. Customer\n"
				+ "3.Exit");
		
		switch(scn.nextInt()) {
		

		case 1:
		{	
		System.out.println("Username : ");
		String un = scn.next();
		System.out.println("Password : ");
		String pwd = scn.next();
		try {
			ref.Account_Validation(un, pwd, 1);
			System.out.println("Login Successful");
		}
		catch (PersonException p){
			System.out.println(p.getMessage());
			break out;
		
		}
		while(true) {
		System.out.println("Welcome to World Of Laptops \n"
				+ "1. Add Laptop \n"
				+ "2. Search By ID \n"
				+ "3. Display All Laptop\n"
				+ "4. Logout\n");
		switch(scn.nextInt()) {
		case 1:
			System.out.println("Enter Details Of Laptop");
			//Lp_obj.setLaptop_ID(scn.nextInt());
			Lp_obj.setName(scn.next());
			Lp_obj.setRAM(scn.nextInt());
			Lp_obj.setStorage(scn.nextInt());
			Lp_obj.setPrice(scn.nextFloat());
			ref.Add_Laptop(Lp_obj);
			System.out.println("DATA ADDED SUCCESSFULLY\n");
			break;
		case 2:
			System.out.println("Enter ID");
			try {
				System.out.println(ref.search_by_id(scn.nextInt()));
				//ref.Search_Mobile(scn.next());
			}
			catch(PersonException p){
			System.out.println(p.getMessage());
			}
			break;
		case 3:
			System.out.println(ref.display_all());
			break;
		
		case 4: break out;
		}	
		}
		}
		
		case 2:
		{
			System.out.println("1.Sign In\n"
					+ "2.Sign Up");
			switch(scn.nextInt()) {
			
			case 1:
			System.out.println("Username : ");
			String un = scn.next();
			System.out.println("Password : ");
			String pwd = scn.next();
			try {
				ref.Account_Validation(un, pwd, 0);
				System.out.println("Login Successful");
			}
			catch (PersonException p){
				System.out.println(p.getMessage()); 
				break out;
			}
			while(true) {
			System.out.println("Welcome to World Of Laptops \n"
					+ "1. Display All Laptops\n"
					+ "2.Logout");
				switch(scn.nextInt()) {
				case 1:	System.out.println(ref.display_all());
						break;
				case 2: break out;
			}
		}
			case 2:
				System.out.println("Enter Username");
				un = scn.next();
				System.out.println("Enter Password");
				pwd = scn.next();
				ref.Create_Account(un, pwd);
				break out;
		}
		}
		
		case 3:
			System.exit(0);
		}
	}
	}	
}
	
