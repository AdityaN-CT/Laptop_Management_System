package com.LaptopManagementSystem.ServiceLayer;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;

import com.LaptopManagementSystem.Database.*;
import com.LaptopManagementSystem.Exception.PersonException;
import com.LaptopManagementSystem.model.Laptop;

public class ServiceLayerImpl implements IServiceLayer {
	ILaptopDAO ref = new LaptopDAOImpl();
	@Override
	public void Account_Validation(String un, String pwd, int option) throws FileNotFoundException, IOException, PersonException {
		ref.Account_Validation(un, pwd, option);
		
	}
	@Override
	public void Add_Laptop(Laptop lp_obj) throws IOException, PersonException {
		ref.Add_Laptop(lp_obj);
		
	}
	@Override
	public Laptop search_by_id(int ID) throws PersonException {
		return ref.search_by_id(ID);
		
	}
	@Override
	public Collection display_all() throws PersonException {
		
		return ref.display_all();
	}
	@Override
	public void Create_Account(String un, String pwd) throws PersonException, IOException {
		// TODO Auto-generated method stub
		ref.Create_Account(un, pwd);
	}

}
