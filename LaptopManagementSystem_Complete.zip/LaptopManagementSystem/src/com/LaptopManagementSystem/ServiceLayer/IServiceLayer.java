package com.LaptopManagementSystem.ServiceLayer;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.LaptopManagementSystem.Exception.PersonException;
import com.LaptopManagementSystem.model.Laptop;

public interface IServiceLayer {
	public void Account_Validation(String un, String pwd, int option) throws FileNotFoundException, IOException, PersonException;

	public void Add_Laptop(Laptop lp_obj) throws FileNotFoundException, IOException, PersonException;

	public Laptop search_by_id(int id) throws PersonException;

	public Object display_all() throws PersonException;
	
	public void Create_Account(String un, String pwd) throws PersonException, IOException;
}
