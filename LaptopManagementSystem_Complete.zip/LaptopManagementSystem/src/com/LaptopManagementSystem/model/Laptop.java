package com.LaptopManagementSystem.model;

public class Laptop {
	private int Laptop_ID;
	private String Name;
	private int RAM;
	private int Storage;
	private float Price;
	public int getLaptop_ID() {
		return Laptop_ID;
	}
	public void setLaptop_ID(int laptop_ID) {
		Laptop_ID = laptop_ID;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getRAM() {
		return RAM;
	}
	public void setRAM(int rAM) {
		RAM = rAM;
	}
	public int getStorage() {
		return Storage;
	}
	public void setStorage(int storage) {
		Storage = storage;
	}
	public float getPrice() {
		return Price;
	}
	public void setPrice(float price) {
		Price = price;
	}
	@Override
	public String toString() {
		return "Laptop [Laptop_ID=" + Laptop_ID + ", Name=" + Name + ", RAM=" + RAM + ", Storage=" + Storage
				+ ", Price=" + Price + "]";
	}
	
}
