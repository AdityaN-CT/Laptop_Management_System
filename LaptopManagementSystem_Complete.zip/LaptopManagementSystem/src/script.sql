Select * from LaptopDetails
