package com.ct.Model;

public class Filter {
	
	private String[] brandList;

	public Filter() {
		// TODO Auto-generated constructor stub
	}
	
	public String[] getBrandList() {
		return brandList;
	}

	public void setBrandList(String[] brandList) {
		this.brandList = brandList;
	}
	
}
