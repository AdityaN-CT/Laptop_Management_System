package com.ct.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ct.Model.Account;
import com.ct.Model.Filter;
import com.ct.Model.Laptop;
import com.ct.Model.Login;
import com.ct.Service.Iservice;
import com.ct.Service.ServiceLayer;


@Controller
public class LaptopController {
	
	@Autowired
	ServiceLayer serviceObj;
	public LaptopController() {
	
	}
	
	@RequestMapping("/")
	public ModelAndView indexPage() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("login_details", new Login());
		mv.addObject("accDetails", new Account());
		mv.setViewName("index");
		return mv;
	}
	
	
	@RequestMapping(value = "/signUp", method = RequestMethod.POST )
		public String createAccount(@ModelAttribute("accDetails") Account accObj) {
		System.out.println("acc");
		
			return serviceObj.createAccount(accObj);
		
	}

	@RequestMapping(value = "/loginDetails", method = RequestMethod.POST)
	public String loginVerification(@ModelAttribute("login_details") Login logObj) {
		return serviceObj.accountValidation(logObj);
		
	}
	
	@RequestMapping("/addDetails")
	public ModelAndView addObj() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("lapObj", new Laptop());
		mv.setViewName("add");
		return mv;
	}
	
	@RequestMapping(value ="/addDetails", method = RequestMethod.POST)
	public String addDetails(@ModelAttribute("lapObj") Laptop lapObj) {
		
		return serviceObj.addDetails(lapObj);
	}
	
	@RequestMapping("/display")
	public ModelAndView displayAll() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("listofLaptop", serviceObj.displayAll());
		mv.setViewName("displayAll");
		return mv;
	}
	
	@ModelAttribute("brandLists")
	public List<String> getBrandList(){
		List<String> brandList = new ArrayList<String>();
		brandList.add("Asus");
		brandList.add("HP");
		brandList.add("Dell");
		brandList.add("Acer");
		brandList.add("Alienware");
		return brandList;
	}
	
	@RequestMapping(value = "/filter", method = RequestMethod.GET)
	public ModelAndView filter() {
		ModelAndView mv = new ModelAndView("filter", "command", new Filter());
		//mv.addObject("filter", new Filter());
		//mv.setViewName("filter");
		System.out.println("here2");
		return mv;
	}
	
	@RequestMapping(value="/filterList", method = RequestMethod.POST)
	public String filterList(@ModelAttribute("filter") Filter filter, ModelMap m ) {
		System.out.println("here1");
		m.addAttribute("brandList", filter.getBrandList());
		System.out.println("here");
		return "displayFilter";	
	}
	
}
