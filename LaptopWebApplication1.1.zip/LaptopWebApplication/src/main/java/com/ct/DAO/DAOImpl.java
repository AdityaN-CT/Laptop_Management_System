package com.ct.DAO;

import java.util.List;

import javax.sql.DataSource;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.ct.Model.Account;
import com.ct.Model.Laptop;
import com.ct.Model.Login;

@Component("databaseObj")
public class DAOImpl implements IDAO {
	
	
	SessionFactory sess = new Configuration().configure().buildSessionFactory();
	String query;
	/*private JdbcTemplate jdbcTemp;
	
	@Autowired
	public void setDatasource(DataSource datasource) {
		this.jdbcTemp = new JdbcTemplate(datasource);
	}*/
	
	public String accountValidation(Login logObj) {
		Session session = sess.openSession();
		String userName = logObj.getUserName();
		String password = logObj.getPassword();
		if ("admin".equals(userName) && "admin".equals(password)) {
			return "homePage";
		}
		else {
			Account dbObj = (Account) session.get(Account.class, userName);
			if (password.equals(dbObj.getPassword())){
				return "homePageCustomer";
			}
			else {
				return "login";
			}
		}
		
	}

	public String createAccount(Account accObj) {
		Session session = sess.openSession();
		session.beginTransaction();
		Transaction tx = session.getTransaction();
		session.save(accObj);
		tx.commit();
		session.close();
		
		return "homePageCustomer";
		
	}

	public String addDetails(Laptop lapObj) {
		Session session = sess.openSession();
		session.beginTransaction();
		Transaction tx = session.getTransaction();
		session.save(lapObj);
		tx.commit();
		session.close();
		return "homePage";
	}

	public String searchByID() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Laptop> displayAll() {
		Session session = sess.openSession();
		session.beginTransaction();
	    Criteria crit = session.createCriteria(Laptop.class);
	    List<Laptop> l = crit.list();
		return l;
	}

	
	
}
