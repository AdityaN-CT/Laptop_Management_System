package com.ct.DAO;

import java.util.List;

import org.springframework.stereotype.Component;

import com.ct.Model.*;

@Component
public interface IDAO {
	public String accountValidation(Login logObj); 
	public String createAccount(Account accObj);
	public String addDetails(Laptop lapObj);
	public String searchByID();
	public List<Laptop> displayAll();
	
}
