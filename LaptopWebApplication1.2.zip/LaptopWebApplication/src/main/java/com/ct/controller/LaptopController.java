package com.ct.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ct.Model.Account;
import com.ct.Model.Filter;
import com.ct.Model.Laptop;
import com.ct.Model.Login;
import com.ct.Service.Iservice;
import com.ct.Service.ServiceLayer;


@Controller
public class LaptopController {
	
	@Autowired
	ServiceLayer serviceObj;
	public LaptopController() {
	
	}
	
	@RequestMapping("/")
	public ModelAndView indexPage() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("login_details", new Login());
		mv.addObject("accDetails", new Account());
		mv.setViewName("index");
		return mv;
	}
	
	
	@RequestMapping(value = "/signUp", method = RequestMethod.POST )
		public String createAccount(@Valid @ModelAttribute("accDetails") Account accObj, BindingResult br, HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		if(br.hasErrors()) {
			System.out.println("errors");
			request.setAttribute("login_details",new Login());
		
			

			return "index";
		}
		else {	
			System.out.println("hereeeeee");
			return serviceObj.createAccount(accObj);
		}
		

	}

	@RequestMapping(value = "/loginDetails", method = RequestMethod.POST)
	public String loginVerification( @ModelAttribute("login_details") Login logObj) {
	

			return serviceObj.accountValidation(logObj);
		
	}
	
	@RequestMapping("/addDetails")
	public ModelAndView addObj() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("lapObj", new Laptop());
		mv.setViewName("add");
		return mv;
	}
	
	@RequestMapping(value ="/addDetails", method = RequestMethod.POST)
	public String addDetails(@ModelAttribute("lapObj") Laptop lapObj) {
		System.out.println(lapObj);
		return serviceObj.addDetails(lapObj);
	}
	
	@RequestMapping("/display")
	public ModelAndView displayAll() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("listofLaptop", serviceObj.displayAll());
		mv.setViewName("displayAll");
		return mv;
	}
	
	@ModelAttribute("brandLists")
	public List<String> getBrandList(){
		List<String> brandList = new ArrayList<String>();
		brandList.add("Asus");
		brandList.add("HP");
		brandList.add("Dell");
		brandList.add("Acer");
		brandList.add("Alienware");
		return brandList;
	}
	
	@ModelAttribute("ramList")
	public List<String> getRamList(){
		List<String> ramList = new ArrayList<String>();
		ramList.add("4");
		ramList.add("8");
		return ramList;
	}
	
	
	@ModelAttribute("storageList")
	public List<String> getStorageList(){
		List<String> storageList = new ArrayList<String>();
		storageList.add("256");
		storageList.add("500");
		storageList.add("1000");
		return storageList;
	}
	@RequestMapping(value = "/filter", method = RequestMethod.GET)
	public ModelAndView filter() {
		ModelAndView mv = new ModelAndView("filter", "command", new Filter());
		System.out.println("here2");
		return mv;
	}
	
	@RequestMapping(value="/filterList", method = RequestMethod.POST)
	public String filterList(@ModelAttribute("filter") Filter filter, ModelMap m ) {
		System.out.println("here1");
		m.addAttribute("brandList", filter.getBrandList());
		m.addAttribute("ramList", filter.getRamList());
		m.addAttribute("storageList", filter.getStorageList());
		m.addAttribute("listofLaptop",serviceObj.displayAll() );
		ModelAndView mv = new ModelAndView();
		//mv.addObject("listofLaptop", serviceObj.displayAll());
		//mv.addObject("brandList",  filter.getBrandList());
		System.out.println("here");
		return "displayFilter";	
	}
	
}
