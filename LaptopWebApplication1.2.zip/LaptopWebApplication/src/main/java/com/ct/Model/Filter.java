package com.ct.Model;

public class Filter {
	
	private String[] brandList;
	private String[] ramList;
	private String[] storageList;

	public Filter() {
		// TODO Auto-generated constructor stub
	}
	
	public String[] getBrandList() {
		return brandList;
	}

	public void setBrandList(String[] brandList) {
		this.brandList = brandList;
	}

	public String[] getRamList() {
		return ramList;
	}

	public void setRamList(String[] ramList) {
		this.ramList = ramList;
	}

	public String[] getStorageList() {
		return storageList;
	}

	public void setStorageList(String[] storageList) {
		this.storageList = storageList;
	}
	
	
}
