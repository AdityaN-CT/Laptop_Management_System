package com.ct.Model;

import javax.persistence.*;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

@Entity
@Table(name = "laptop_details", schema ="test")
public class Laptop {
	@Id
	@GeneratedValue
	private int laptopId;
	
	private String brandName;
	private String modelName;
	private int RAM;
	private int storage;
	private float price;
	/*private CommonsMultipartFile image;*/
	
	public Laptop() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Laptop [laptopId=" + laptopId + ", brandName=" + brandName + ", modelName=" + modelName + ", RAM=" + RAM
				+ ", storage=" + storage + ", price=" + price + "]";
	}

	public int getLaptopId() {
		return laptopId;
	}

	public void setLaptopId(int laptopId) {
		this.laptopId = laptopId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public int getRAM() {
		return RAM;
	}

	public void setRAM(int rAM) {
		RAM = rAM;
	}

	public int getStorage() {
		return storage;
	}

	public void setStorage(int storage) {
		this.storage = storage;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
/*
	public CommonsMultipartFile getImage() {
		return image;
	}

	public void setImage(CommonsMultipartFile image) {
		this.image = image;
	}
	*/
	

}
