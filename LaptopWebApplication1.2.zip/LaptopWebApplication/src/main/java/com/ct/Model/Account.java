package com.ct.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;



//mport org.hibernate.validator.constraints.Email;

@Entity
@Table(name = "account_details", schema = "test")
public class Account {

		@Id
		//@Email
		private String userName;
		
		//@Size(min = 8, message = "Password length must be greater than 8")
	
		@Size(min = 8,message = "Password length must be greater than 8")
		private String password;
		
		private long mobileNo;
		private String address;
		private String city;
		private int coins = 0;
		
		public Account() {
			// TODO Auto-generated constructor stub
		}
		

		public Account(String userName, String password, long mobileNo, String address, String city, int coins) {
			super();
			this.userName = userName;
			this.password = password;
			this.mobileNo = mobileNo;
			this.address = address;
			this.city = city;
			this.coins = coins;
		}


		public String getUserName() {
			return userName;
		}

		public void setUserName(String userName) {
			this.userName = userName;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public long getMobileNo() {
			return mobileNo;
		}

		public void setMobileNo(long mobileNo) {
			this.mobileNo = mobileNo;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public int getCoins() {
			return coins;
		}

		public void setCoins(int coins) {
			this.coins = coins;
		}
		
		
		
}
