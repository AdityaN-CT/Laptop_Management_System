package com.ct.Service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.ct.Model.Account;
import com.ct.Model.Laptop;
import com.ct.Model.Login;

@Component
public interface Iservice {

	public String accountValidation(Login logObj);
	public String createAccount(Account accObj);
	public String addDetails(Laptop lapObj);
	public List<Laptop> displayAll();

}
